import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.ems.util.JPAUtil;

public class TestInheritanceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Emp akki=new Emp();
		akki.setEmpName("Akrai Agrawal");
		akki.setEmpSal(5600.0F);
		Manager akku=new Manager();
		akku.setEmpName("AkratiAg");
		akku.setEmpSal(89000.0F);
		akku.setDeptName("Java");
		EntityManager em=JPAUtil.getEntityManager();
		EntityTransaction tran=em.getTransaction();
		tran.begin();
		em.persist(akki);
		em.persist(akku);
		tran.commit();
		System.out.println("Data is inserted...");
		//here 15 is the id of emp
		Manager ee1=em.find(Manager.class,17);
		System.out.println(ee1.getEmpName());
	}

}
