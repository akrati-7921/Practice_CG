package com.cg.mr.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.mr.bean.Customer;
@Repository
public class EmployeeDAO implements IEmployeeDAO 
{
	@PersistenceContext
	EntityManager em;

	@Override
	public String createCustomer(Customer customer) 
	{
		em.persist(customer);
		return " Customer added successfully";
	}

	@Override
	public String Recharge(String mobile, double amount) 
	{
		System.out.println(mobile);
		System.out.println(amount);
		Customer customer=new Customer();
		//customer = em.createQuery("SELECT c FROM Customer c where c.mobileNo = :mobile", Customer.class).setParameter("mobile", mobile).getSingleResult();
		
		//customer=query.getSingleResult();
		customer=em.find(Customer.class, mobile);
		System.out.println(customer);
		
		customer.setBalanace(customer.getBalanace()+amount);
		em.merge(customer);
		return "Your account is successfully recharge..... \n Your current balance is " +Double.toString(customer.getBalanace());
	}

	@Override
	public Customer showCustomer(String mobileno) 
	{
		Customer customer;
		customer= em.createQuery("SELECT c FROM Customer c where c.mobileNo = :mobile1", Customer.class).setParameter("mobile1", mobileno).getSingleResult();
		return customer;
	}

}
