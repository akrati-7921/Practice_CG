package com.capgemini.exception;

public class MobileNumberAlreadyExistsException extends Exception {

}
