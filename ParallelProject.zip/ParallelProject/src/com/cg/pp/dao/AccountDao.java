package com.cg.pp.dao;

import java.util.Map;

import com.cg.pp.bean.Account;
import com.cg.pp.bean.AccountHolder;
import com.cg.pp.util.CollectionUtil;

public class AccountDao implements IAccountDao{

	CollectionUtil collect=null;
	Map<Integer,Account> accountMap=null;
	Account account=null;
	double balance=0.0;
	
	public AccountDao() {
		// TODO Auto-generated constructor stub
		collect=new CollectionUtil();
		accountMap=collect.getAccountDetails();
	}

	@Override
	public void createAccount(int accNo, String name, String mobileNo, double amount) {
		// TODO Auto-generated method stub
		accountMap.put(accNo,new Account(amount,new AccountHolder(name,mobileNo)));
		System.out.println(accountMap);
	}

	@Override
	public void withdraw(int accNo,double amount) {
		// TODO Auto-generated method stub
		account=accountMap.get(accNo);
		balance=account.getBalance();
		balance=balance-amount;
		account.setBalance(balance);
	}

	@Override
	public void deposit(int accNo,double amount) {
		// TODO Auto-generated method stub
		account=accountMap.get(accNo);
		balance=account.getBalance();
		balance=balance+amount;
		account.setBalance(balance);
	}

	@Override
	public double showBalance(int accNo) {
		// TODO Auto-generated method stub
		account=accountMap.get(accNo);
		return account.getBalance();
	}

	@Override
	public Account printTtansaction(int accNo) {
		// TODO Auto-generated method stub
		account=accountMap.get(accNo);
		return account;
	}

	@Override
	public void fundTransfer(int senderAccNo,int receiverAccNo, double amount) {
		// TODO Auto-generated method stub
		Account senderAccount=accountMap.get(senderAccNo);
		Account receiverAccount=accountMap.get(receiverAccNo);
		double receiverAmount=receiverAccount.getBalance();
		receiverAmount=receiverAmount-amount;
		double senderAmount=senderAccount.getBalance();
		senderAmount=senderAmount+amount;
		senderAccount.setBalance(senderAmount);
		receiverAccount.setBalance(receiverAmount);
	}

}
