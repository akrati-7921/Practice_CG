package com.cg.hr.core.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import com.cg.hr.core.bean.Employee;
import com.cg.hr.core.exception.EmpException;
import com.cg.hr.core.util.JDBCUtil;


public class EmployeeDaoImpl implements EmployeeDao{

	private Connection connect;
	
	public EmployeeDaoImpl() throws EmpException
	{
		JDBCUtil util=new JDBCUtil();
		connect=util.getConnect();
	}
	
	@Override
	public ArrayList<Employee> fetchAllEmp() throws EmpException{
		// TODO Auto-generated method stub
		Statement stmt =null;
		ResultSet rs=null;
		ArrayList<Employee> empList=new ArrayList();
		try {
			stmt =connect.createStatement();
			rs=stmt.executeQuery("Select * from emp1");
			while(rs.next())
			{
				int emp_id= rs.getInt("emp_id");
				String emp_name=rs.getString("emp_name");
				float emp_sal=rs.getFloat("emp_sal");
				Employee emp=new Employee(emp_id,emp_name,emp_sal);
				empList.add(emp);
			}
			return empList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new EmpException("Something wrong in fetchAllEmp()",e);
		}
		finally
		{
			try {
				if(rs!= null)
				{
					rs.close();
				}
				if(stmt!=null)
				{
					stmt.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public Employee getEmpbyEid(int empId) throws EmpException {
		// TODO Auto-generated method stub
		PreparedStatement pstmt =null;
		ResultSet rs=null;
		Employee emp=null;
		try {
			pstmt =connect.prepareStatement("Select * from emp1 where emp_id=?");
			pstmt.setInt(1,empId);
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				int emp_id= rs.getInt("emp_id");
				String emp_name=rs.getString("emp_name");
				float emp_sal=rs.getFloat("emp_sal");
				emp=new Employee(emp_id,emp_name,emp_sal);
			}
			return emp;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new EmpException("Something wrong in fetchAllEmp()",e);
		}
		finally
		{
			try {
				if(rs!= null)
				{
					rs.close();
				}
				if(pstmt!=null)
				{
					pstmt.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		if(connect!=null)
		{
			connect.close();
		}
		super.finalize();
	}
}
