package com.cg.ems.service;

import java.util.ArrayList;
import com.cg.ems.bean.Employee;
import com.cg.ems.dao.EmployeeDAOImpl;

public class EmployeeServiceImpl implements IEmployeeService{

	EmployeeDAOImpl empDao=null;
	
	public EmployeeServiceImpl() {
		// TODO Auto-generated constructor stub
		empDao=new EmployeeDAOImpl();
	}
	
	@Override
	public Employee addEmp(Employee emp) {
		// TODO Auto-generated method stub
		return empDao.addEmp(emp);
	}

	@Override
	public ArrayList<Employee> fetchAllEmp() {
		// TODO Auto-generated method stub
		return empDao.fetchAllEmp();
	}

	@Override
	public Employee deleteEmp(int empId) {
		// TODO Auto-generated method stub
		return empDao.deleteEmp(empId);
	}

	@Override
	public Employee getEmpbyEid(int empId) {
		// TODO Auto-generated method stub
		return empDao.getEmpbyEid(empId);
	}

	@Override
	public Employee updateEmp(int empId, String newName, float newSal) {
		// TODO Auto-generated method stub
		return empDao.updateEmp(empId, newName, newSal);
	}

}
