package com.capgemini.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.capgemini.beans.Account;
import com.capgemini.beans.Options;

public class AccountDAOImpl  implements AccountDAo{
	
	private Map<Integer, Account> accountDetails;
	
	public AccountDAOImpl()
	{
		accountDetails = new TreeMap<>();
		
		Account account1 = new Account();
		account1.setId(1);
		account1.setBalance(4000);
		account1.setName("harshal");
		
		accountDetails.put(account1.getId(), account1);
		
		Account account2 = new Account();
		account2.setId(2);
		account2.setBalance(4000);
		account2.setName("bony");
		
		accountDetails.put(account2.getId(), account2);
		
		Account account3 = new Account();
		account3.setId(3);
		account3.setBalance(4000);
		account3.setName("suresh");
		
		accountDetails.put(account3.getId(), account3);
		
		
		Account account4 = new Account();
		account4.setId(4);
		account4.setBalance(4000);
		account4.setName("ramesh");
		
		accountDetails.put(account4.getId(), account4);
		
	}

	@Override
	public List<Account> findAll() {
		// TODO Auto-generated method stub
		
		List<Account> accounts = new ArrayList<>(accountDetails.values());
		return accounts;
	}

	@Override
	public List<Account> sortAccountDetails(Options option) {
		List<Account> accounts = new ArrayList<>(accountDetails.values());
		
		if(option==Options.byName)
		{
			class CustomComparator implements Comparator<Account>
			{

				@Override
				public int compare(Account o1, Account o2) {
					// TODO Auto-generated method stub
					return o1.getName().compareTo(o2.getName());
				}
				
			}
			Collections.sort(accounts, new CustomComparator());
		}
		else if(option==Options.byId)
		{
			class CustomComparator implements Comparator<Account>
			{

				@Override
				public int compare(Account o1, Account o2) {
					// TODO Auto-generated method stub
					return o1.getId()-o2.getId();
				}
				
			}
			Collections.sort(accounts, new CustomComparator());
			
		}
		return accounts;
	}

	@Override
	public boolean create(Account newAccount) {
		// TODO Auto-generated method stub
		
		Account accountRef;
		accountRef = accountDetails.putIfAbsent(newAccount.getId(), newAccount);
		if(accountRef==null)
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}

	@Override
	public boolean delete(int id) {
		// TODO Auto-generated method stub
		
		Account accountRef;
		accountRef = accountDetails.remove(id);
		System.out.println(accountRef.getName()+" is now removed...");
		return true;
	}

	@Override
	public boolean update(int id, Account account) {
		// TODO Auto-generated method stub
		if(accountDetails.get(id)==null)
		{
			System.out.println("this type of account does not exist");
			return false;
		}
		
		else
		{
			Account accountRef3;
			accountRef3=accountDetails.put(id, account);
			System.out.println("Account updated...");
			return true;
		}
	}

	@Override
	public Account findById(int id) {
		// TODO Auto-generated method stub
		if(accountDetails.get(id)==null)
		{
			System.out.println("this type of account does not exist");
			return null;
			
		}
		else
		{
			
			return accountDetails.get(id);
		}
		
	}
	
	
	
}
