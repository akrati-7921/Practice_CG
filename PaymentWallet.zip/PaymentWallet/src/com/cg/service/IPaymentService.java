package com.cg.service;

import com.cg.bean.Customer;

public interface IPaymentService {

	public Customer createAccount(String name,String phone, double amount);
	public Customer showBalance(String phone);
}
