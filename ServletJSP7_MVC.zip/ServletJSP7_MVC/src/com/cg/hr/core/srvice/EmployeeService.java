package com.cg.hr.core.srvice;

import java.util.ArrayList;

import com.cg.hr.core.bean.Employee;
import com.cg.hr.core.exception.EmpException;

public interface EmployeeService {

	public ArrayList<Employee> fetchAllEmp() throws EmpException;
	public Employee getEmpbyEid(int empId) throws EmpException;
}
