package com.cg.practice_work.bean;

public class Product {

	private String Category;
	private String ProductName;
	private int price;
	
	
	public Product() {
		super();
	}

	public Product(String category, String productName, int price) {
		super();
		Category = category;
		ProductName = productName;
		this.price = price;
	}

	public String getCategory() {
		return Category;
	}
	
	public void setCategory(String category) {
		Category = category;
	}
	
	public String getProductName() {
		return ProductName;
	}
	
	public void setProductName(String productName) {
		ProductName = productName;
	}
	
	public int getPrice() {
		return price;
	}
	
	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Product [Category=" + Category + ", ProductName=" + ProductName + ", price=" + price + "]";
	}
	
	
	
}
