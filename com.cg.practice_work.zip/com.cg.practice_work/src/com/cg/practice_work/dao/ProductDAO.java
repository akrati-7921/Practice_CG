package com.cg.practice_work.dao;

import java.util.HashMap;
import java.util.Map;

public class ProductDAO implements IProductDAO{

	public static Map<String,String> productDetails;
	public static Map<String,Integer> salesDetails;
	public static String updated;
	static
	{
		productDetails=new HashMap();
		productDetails.put("lux", "soap");
		productDetails.put("colgate", "paste");
		productDetails.put("pears", "soap");
		productDetails.put("sony", "electronics");
		salesDetails=new HashMap();
		salesDetails.put("lux",30);
		salesDetails.put("colgate", 50);
		salesDetails.put("pears",70);
		salesDetails.put("sony",10000);
	}
	@Override
	public int updateProducts(String Category, int hike) {
		// TODO Auto-generated method stub
		int flag=0;
		updated=Category;
		if(productDetails.containsKey(Category))
		{
			if(salesDetails.containsKey(Category))
			{
				int price=salesDetails.get(Category);
				salesDetails.replace(Category, price, price+hike);
				flag=1;
			}
		}
		return flag;
		
	}

	@Override
	public Map<String, Integer> getProductDetails() {
		// TODO Auto-generated method stub
		Map<String,Integer> result=new HashMap();
		if(salesDetails.containsKey(updated))
		{
			result.put(updated,salesDetails.get(updated));
			return result;
		}
		return null;
	}

	
}
