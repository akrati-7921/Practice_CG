import java.util.List;

import com.capgemini.beans.Account;
import com.capgemini.dao.AccountDAOImpl;
import com.capgemini.service.AccountService;
import com.capgemini.service.AccountServiceImpl;

public class Entry {
	
	public static void main(String[] args) {
		
		AccountService service = new AccountServiceImpl();
		
		Account newAccount = new Account();
		newAccount.setId(5);
		newAccount.setBalance(1200);
		newAccount.setName("Tiger");
		
		boolean flag = service.create(newAccount);
		System.out.println("New Account Created? "+flag);
		
		System.out.println("-----------------------------------------");
		
		
		boolean flag1=service.delete(2);
		System.out.println("Is id deleted? "+flag1);
		System.out.println();
		
		
		List<Account> accounts = service.findAll();
		
		for(Account account:accounts)
		{
			System.out.println(account);
			System.out.println("-------------------------------------");
		}
		
		System.out.println("Account details by this id are: \n"+service.findById(3));
		
		System.out.println("-------------------------------------");
		
		Account upaccount = new Account();
		upaccount.setId(4);
		upaccount.setBalance(45000);
		upaccount.setName("dubey");
		
		boolean flag3 =  service.update(4, upaccount);
		System.out.println(flag3);
		System.out.println("-------------------------------------");
		
		
		 accounts = service.findAll();
		for(Account account:accounts)
		{
			System.out.println(account);
			System.out.println("-------------------------------------");
		}
		
	}

}
