package jdbcProject;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.ems.util.DBUtil;

public class TestTransactionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Connection con=null;
		
		try {
			con=DBUtil.getCon();
			con.setAutoCommit(false);
			String update1="UPDATE emp1 SET emp_name='Aks' WHERE emp_id=111";
			String update2="UPDATE emp1 SET emp_sal=63000 WHERE emp_id=333";
			Statement st=con.createStatement();
			st.addBatch(update1);
			st.addBatch(update2);
			int[] arr=st.executeBatch();
			con.commit();
			System.out.println("Update sucess...");
		} 
		catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			try {
				con.rollback();
			}
			catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
	}

}
