package com.cg.practice_work.service;


import java.util.Map;

import com.cg.practice_work.dao.ProductDAO;

public class ProductService implements IProductService{

	ProductDAO dao=new ProductDAO();
	
	@Override
	public int updateProducts(String Category, int hike) {
		// TODO Auto-generated method stub
		int result=dao.updateProducts(Category, hike);
		if(result==1)
		{
			return 1;
		}
		else
		{
			return 0;
		}
		
	}

	@Override
	public Map<String, Integer> getProductDetails() {
		// TODO Auto-generated method stub
		Map<String,Integer> resultant=dao.getProductDetails();
		return resultant;
	}
	
}
