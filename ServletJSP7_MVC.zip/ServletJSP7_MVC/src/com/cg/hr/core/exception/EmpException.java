package com.cg.hr.core.exception;

public class EmpException extends Exception{

	private static final long serialVersionUID = 1L;

	public EmpException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public EmpException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
