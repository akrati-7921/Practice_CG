package com.cg.practice_work.main;

import java.util.Scanner;

import com.cg.practice_work.service.ProductService;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ProductService product=new ProductService();
		while(true)
		{
			System.out.println("1. Update Product Price\n2. Exit\nEnter your choice");
			Scanner scan=new Scanner(System.in);
			int choice=scan.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("Enter the category");
				String cat=scan.next();
				System.out.println("Enetr hike rate");
				int hike=scan.nextInt();
				int n=product.updateProducts(cat, hike);
				if(n==1)
				{
					System.out.println(product.getProductDetails());
				}
				break;
			case 2:
				System.exit(0);
				break;
			default: 
				System.out.println("Entered wrong option");
				break;
					
			}
		}

	}

}
