package com.cg.ui;

import java.util.Scanner;

import com.cg.bean.Customer;
import com.cg.service.PaymentService;

public class Payment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Customer cust=new Customer();
		PaymentService ser=new PaymentService();
		Scanner scan=new Scanner(System.in);
		while(true)
		{
			System.out.println("1. Create Account\n2. Show Balance\n3. Exit\nEnter your choice");
			int choice=scan.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("Enter name");
				String name=scan.nextLine();
				System.out.println("Enter phone number");
				String phone=scan.nextLine();
				System.out.println("Enter amount");
				double amount=scan.nextDouble();
				cust=ser.createAccount(name, phone, amount);
				System.out.println(cust);
				break;
			case 2:
				System.out.println("Enter phone number whose details u want");
				String phoneNo=scan.nextLine();
				cust=ser.showBalance(phoneNo);
				System.out.println(cust);
				break;
			case 3:
				System.exit(0);
				break;
			default: 
				System.out.println("Wrong Option");
				break;
			}
		}
	}

}
