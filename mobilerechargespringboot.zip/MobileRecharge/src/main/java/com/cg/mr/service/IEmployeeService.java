package com.cg.mr.service;

import org.springframework.stereotype.Service;

import com.cg.mr.bean.Customer;

@Service
public interface IEmployeeService 
{
	public String createCustomer(Customer customer);
	public String Recharge(String mobileno,double amount);
	public Customer showCustomer(String mobileno);

}
