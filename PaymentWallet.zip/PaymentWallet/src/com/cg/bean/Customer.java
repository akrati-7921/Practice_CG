package com.cg.bean;

public class Customer {

	private String name;
	private String phoneNo;
	Wallet wallet;
	
	public Customer() {
		super();
	}

	public Customer(String name, String phoneNo) {
		super();
		this.name = name;
		this.phoneNo = phoneNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public Wallet getWallet() {
		return wallet;
	}

	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}

	@Override
	public String toString() {
		return "Customer [name=" + name + ", phoneNo=" + phoneNo + ", wallet=" + wallet.getBalance() + "]";
	}
	
	
	
}
