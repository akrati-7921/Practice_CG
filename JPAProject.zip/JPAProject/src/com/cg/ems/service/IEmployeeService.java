package com.cg.ems.service;

import java.util.ArrayList;

import com.cg.ems.bean.Employee;

public interface IEmployeeService {

	public Employee addEmp(Employee emp);
	public ArrayList<Employee> fetchAllEmp();
	public Employee deleteEmp(int empId);
	public Employee getEmpbyEid(int empId);
	public Employee updateEmp(int empId,String newName,float newSal);
}
