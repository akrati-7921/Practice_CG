package com.cg.beans;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Client {
	
	public static void main(String ag[])
	{
		Resource res= new ClassPathResource("beans.xml");
		XmlBeanFactory factory=new XmlBeanFactory(res);
		
		/*Employee emp=(Employee) factory.getBean("emp");
		UserCredentials cred=factory.getBean(UserCredentials.class);
		System.out.println(emp);
		System.out.println(cred);
		*/
		
		Employee e1=(Employee) factory.getBean("e1");
		Employee e2=(Employee) factory.getBean("e2");
		System.out.println(e1+"\n"+e2);
	}
}
