package com.cg.hr.core.ui;

import java.util.ArrayList;

import com.cg.hr.core.bean.Employee;
import com.cg.hr.core.exception.EmpException;
import com.cg.hr.core.srvice.EmployeeService;
import com.cg.hr.core.srvice.EmployeeServiceImpl;

public class TestEmpList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			EmployeeService service=new EmployeeServiceImpl();
			ArrayList<Employee> emplist=service.fetchAllEmp();
			
			for(Employee emp:emplist) {
				System.out.println(emp);
			}
		} catch (EmpException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
