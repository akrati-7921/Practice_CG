package com.cg.hr.core.srvice;

import java.util.ArrayList;

import com.cg.hr.core.bean.Employee;
import com.cg.hr.core.dao.EmployeeDaoImpl;
import com.cg.hr.core.exception.EmpException;

public class EmployeeServiceImpl implements EmployeeService{

	EmployeeDaoImpl empDao=null;
	
	public EmployeeServiceImpl() throws EmpException {
		// TODO Auto-generated constructor stub
		empDao=new EmployeeDaoImpl();
	}

	@Override
	public ArrayList<Employee> fetchAllEmp() throws EmpException {
		// TODO Auto-generated method stub
		return empDao.fetchAllEmp();
	}
	
	@Override
	public Employee getEmpbyEid(int empId) throws EmpException {
		// TODO Auto-generated method stub
		return empDao.getEmpbyEid(empId);
	}
}
