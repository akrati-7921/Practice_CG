package com.cg.bean;

public class Wallet {

	private int id;
	private double balance;
	
	public Wallet() {
		super();
	}

	public Wallet(double balance) {
		super();
		this.balance = balance;
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public double getBalance() {
		return balance;
	}
	
	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Wallet [id=" + id + ", balance=" + balance + "]";
	}
	
}
