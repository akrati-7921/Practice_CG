package com.capgemini.takehome.exception;

public class QuantityException extends Exception{
	
	private static final long serialVersionUID = 1L;
	
	public String quantity;

	public QuantityException(String quantity) {
		super();
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "QuantityException:  "+quantity;
	}
	
	

}
