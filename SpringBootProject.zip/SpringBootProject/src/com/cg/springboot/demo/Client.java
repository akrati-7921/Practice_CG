package com.cg.springboot.demo;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableAutoConfiguration
@ComponentScan("com.cg")
public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//ApplicationContext contxt=SpringApplication.run(Client.class,agr0);---- for spring boot
		ApplicationContext context=new AnnotationConfigApplicationContext(Client.class); //by using annotation
		Employee ep=(Employee) context.getBean("emp");
		System.out.println(ep);
	}

}
