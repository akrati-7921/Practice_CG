package com.cg.repository;

import java.util.Map;

import com.cg.bean.Customer;
import com.cg.bean.Wallet;

public class PaymentRepository implements IPaymentRepository{

	Customer customer;
	public static Map<Integer,Customer> cust;
	public static Map<Integer,Wallet> wall;
	static
	{
		cust.put(101,new Customer("Akrati","7088559555"));
		cust.put(102,new Customer("Akku","7055896453"));
		cust.put(103,new Customer("Akki","7055855943"));
		
		wall.put(101,new Wallet(1200));
		wall.put(102,new Wallet(4500));
		wall.put(103,new Wallet(9600));
	}
	@Override
	public Customer createAccount(String name, String phone, double amount) {
		// TODO Auto-generated method stub
		cust.put(104,new Customer(name,phone));
		wall.put(104,new Wallet(amount));
		return customer;
	}

	@Override
	public Customer showBalance(String phone) {
		// TODO Auto-generated method stub
		return null;
	}

}
