package com.cg.springmvc.repo;

import com.cg.springmvc.bean.Customer;

public interface ICustomerRepository {

	public Customer addCustomer(Customer customer);
}
