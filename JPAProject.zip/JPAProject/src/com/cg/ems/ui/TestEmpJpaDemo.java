package com.cg.ems.ui;

import java.util.ArrayList;
import java.util.Scanner;
import com.cg.ems.bean.Employee;
import com.cg.ems.service.EmployeeServiceImpl;
import com.cg.ems.service.IEmployeeService;

public class TestEmpJpaDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		IEmployeeService empSer=new EmployeeServiceImpl();
		Scanner scan=new Scanner(System.in);
		System.out.println("1.Add Employee\n2.Fetch All Employee\n3.Delete Employee\n4."
				+ "Get Employee by Id\n5.Update Employee details\nEnter your choice");
		int choice=scan.nextInt();
		switch(choice)
		{
		case 1:
			/* when we dont use auto for automatic generation then use this
			Employee e1=new Employee(222,"Akki",45000.0F,null);
			Employee e2=new Employee(444,"Akrati",12000.0F,null);
			*/
			Employee e1=new Employee();
			e1.setEmpName("Tuk");
			e1.setEmpSal(23000.0F);
			Employee ee1=empSer.addEmp(e1);
			//Employee ee2=empSer.addEmp(e2);
			System.out.println(ee1);
			
			break;
		case 2:
			System.out.println("Fetch All Records...");
			ArrayList<Employee> eList=empSer.fetchAllEmp();
			for(Employee ee:eList)
			{
				System.out.println(ee.getEmpId()+"\t"+ee.getEmpName()+"\t"+ee.getEmpSal());
			}
			break;
		case 3:
			Employee deletedEmp=empSer.deleteEmp(3);
			System.out.println(deletedEmp+"deleted");
			break;
		case 4:
			Employee ee2=empSer.getEmpbyEid(111);
			System.out.println(ee2);
			break;
		case 5:
			System.out.println("Update...");
			Employee updateE=empSer.updateEmp(444,"Akr",33000.0F);
			System.out.println(updateE.getEmpId());
			break;
		default:
			System.out.println("wrong choice");
			break;
		}		
	}

}
