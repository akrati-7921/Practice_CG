package com.cg.hr;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/authenticate")
public class Authentication extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		//Pick up query string data(Get)
		//Pick a form data(Post)
		// For multiple data String[] = request.getParameterValues(args0)
		//getParameter will return string only and works within browser only 
		//setArgument will send any type of data to jsp within web objects
		
		String userName=request.getParameter("userName");
		String password=request.getParameter("password");
		
		RequestDispatcher dispatch = null;
		if(userName.equals("akku") && (password.equals("akku")))
		{
			String fullName="Akrati Agrawal";
			//Request Scope
			request.setAttribute("fullName",fullName);
			dispatch=request.getRequestDispatcher("/WEB-INF/pages/MainMenu.jsp");
			
		}
		else
		{
			request.setAttribute("message","Wrong Authentication. Pls do again");
			dispatch=request.getRequestDispatcher("/WEB-INF/pages/Login.jsp");
		}
		dispatch.forward(request, response);
		
		System.out.println("User Name: "+userName);
	}
	
	

}
