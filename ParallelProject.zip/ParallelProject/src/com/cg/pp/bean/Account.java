package com.cg.pp.bean;

public class Account {

	private int acc_no;
	private double balance;
	private AccountHolder accHold;
	
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Account(double balance, AccountHolder accHold) {
		super();
		this.balance = balance;
		this.accHold = accHold;
	}

	public int getAcc_no() {
		return acc_no;
	}

	public void setAcc_no(int acc_no) {
		this.acc_no = acc_no;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public AccountHolder getAccHold() {
		return accHold;
	}

	public void setAccHold(AccountHolder accHold) {
		this.accHold = accHold;
	}

	@Override
	public String toString() {
		return "Account [acc_no=" + acc_no + ", balance=" + balance + ", accHold=" + accHold + "]";
	}
	
}
