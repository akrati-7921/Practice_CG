package jdbcProject;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import com.cg.ems.util.DBUtil;

public class TestDeleteDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan=new Scanner(System.in);
		System.out.println("Enter empid u want to delete");
		int eid=scan.nextInt();
		try {
			Connection con=DBUtil.getCon();
			String deleteQry="DELETE from emp1 WHERE emp_id=?";
			PreparedStatement pst=con.prepareStatement(deleteQry);
			pst.setInt(1,eid);
			int data=pst.executeUpdate();
			System.out.println("Data is deleted... "+ data);
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
