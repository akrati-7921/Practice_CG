package com.cg.pp.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.pp.bean.Account;
import com.cg.pp.bean.AccountHolder;

public class CollectionUtil {

	private static Map<Integer,Account> account=new HashMap<Integer, Account>();
	
	static
	{
		account.put(101,new Account(1000,new AccountHolder("Akrati","7088559555")));
	}
	
	public Map<Integer,Account> getAccountDetails()
	{
		return account;
	}
}
