package com.capgemini.exception;

public class PhoneNumberDoesNotExistException extends Exception {

}
