package com.cg.ems.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.cg.ems.bean.Employee;
import com.cg.ems.util.JPAUtil;

public class EmployeeDAOImpl implements IEmployeeDAO{

	EntityManager em=null;
	EntityTransaction entityTran=null;
	
	public EmployeeDAOImpl()
	{
		em=JPAUtil.getEntityManager();
		entityTran=em.getTransaction();
	}
	
	@Override
	public Employee addEmp(Employee emp) {
		// TODO Auto-generated method stub
		
		entityTran.begin();
		em.persist(emp);
		entityTran.commit();
		return emp;
	}

	@Override
	public ArrayList<Employee> fetchAllEmp() {
		// TODO Auto-generated method stub
		// since there is no function for fetching all the information so we use jpql same as sql
		
		String selAllQry="SELECT emps from Employee emps";
		TypedQuery<Employee> tq=em.createQuery(selAllQry,Employee.class);
		ArrayList<Employee> empList=(ArrayList)tq.getResultList();
		return empList;
	}

	@Override
	public Employee deleteEmp(int empId) {
		// TODO Auto-generated method stub
		
		Employee e1=em.find(Employee.class,empId);
		entityTran.begin();
		em.remove(e1);
		entityTran.commit();
		return e1;
	}

	@Override
	public Employee getEmpbyEid(int empId) {
		// TODO Auto-generated method stub
		
		Employee ee=em.find(Employee.class,empId);
		return ee;
	}

	@Override
	public Employee updateEmp(int empId, String newName, float newSal) {
		// TODO Auto-generated method stub
		
		Employee ee=em.find(Employee.class,empId);
		ee.setEmpName(newName);
		ee.setEmpSal(newSal);
		entityTran.begin();
		em.merge(ee);
		entityTran.commit();
		return ee;
	}

}
