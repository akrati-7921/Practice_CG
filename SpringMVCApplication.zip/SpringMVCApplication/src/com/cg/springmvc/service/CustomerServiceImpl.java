package com.cg.springmvc.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springmvc.bean.Customer;
import com.cg.springmvc.repo.ICustomerRepository;

@Transactional
@Service("service")
public class CustomerServiceImpl implements ICustomerService{
	
	@Autowired
	ICustomerRepository repo;

	public ICustomerRepository getRepo() {
		return repo;
	}

	public void setRepo(ICustomerRepository repo) {
		this.repo = repo;
	}

	@Override
	public Customer addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return repo.addCustomer(customer);
	}

}
