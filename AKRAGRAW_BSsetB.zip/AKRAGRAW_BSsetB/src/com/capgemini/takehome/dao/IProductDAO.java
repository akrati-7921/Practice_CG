package com.capgemini.takehome.dao;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.exception.ProductCodeExceeption;
import com.capgemini.takehome.exception.ProductCodeNotPresent;
import com.capgemini.takehome.exception.QuantityException;

public interface IProductDAO {

	public Product getProductDetails(int productCode, int quantity) throws QuantityException, ProductCodeExceeption, ProductCodeNotPresent;
}
