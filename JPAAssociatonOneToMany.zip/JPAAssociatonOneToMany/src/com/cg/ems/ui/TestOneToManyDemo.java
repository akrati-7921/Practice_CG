package com.cg.ems.ui;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.ems.dto.Department;
import com.cg.ems.dto.Employee;
import com.cg.ems.util.JPAUtil;

public class TestOneToManyDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManager em=JPAUtil.getEntityManager();
		EntityTransaction et=em.getTransaction();
		
		Department d1=new Department();
		d1.setDeptcode(10);
		d1.setDeptName("Admin");
		
		Department d2=new Department();
		d2.setDeptcode(20);
		d2.setDeptName("Sales");
		
		Employee e1=new Employee();
		e1.setEmpId(111);
		e1.setEmpName("Akrati");
		e1.setEmpSal(12000.0F);
		e1.setEmpDept(d1);
		
		Employee e2=new Employee();
		e2.setEmpId(222);
		e2.setEmpName("Ramya");
		e2.setEmpSal(10000.0F);
		e2.setEmpDept(d1);
		
		Employee e3=new Employee();
		e3.setEmpId(333);
		e3.setEmpName("Shivangi");
		e3.setEmpSal(8000.0F);
		e3.setEmpDept(d2);
		
		Employee e4=new Employee();
		e4.setEmpId(444);
		e4.setEmpName("Yashasvi");
		e4.setEmpSal(6000.0F);
		e4.setEmpDept(d2);
		
		Set<Employee> adminEmpSet=new HashSet<Employee>();
		Set<Employee> saleEmpSet=new HashSet<Employee>();
		
		adminEmpSet.add(e1);
		adminEmpSet.add(e2);
		
		saleEmpSet.add(e3);
		saleEmpSet.add(e4);
		
		d1.setEmpSet(adminEmpSet);
		d2.setEmpSet(saleEmpSet);
		
		et.begin();
		em.persist(d1);
		em.persist(d2);
		et.commit();
		System.out.println("Department persisted");
	}

}
