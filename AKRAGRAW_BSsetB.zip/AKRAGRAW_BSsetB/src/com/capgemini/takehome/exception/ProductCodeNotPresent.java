package com.capgemini.takehome.exception;

public class ProductCodeNotPresent extends Exception{
	
	
	private static final long serialVersionUID = 1L;


	public ProductCodeNotPresent() {
		super();
		
	}


	@Override
	public String toString() {
		return "Sorry! The Product Code<<product_code>> is not available.";
	}
	
	

}
