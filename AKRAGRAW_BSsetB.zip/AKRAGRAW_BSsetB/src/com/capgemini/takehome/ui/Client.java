package com.capgemini.takehome.ui;

import java.util.Scanner;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.exception.ProductCodeExceeption;
import com.capgemini.takehome.exception.ProductCodeNotPresent;
import com.capgemini.takehome.exception.QuantityException;
import com.capgemini.takehome.service.ProductService;


public class Client {

	public static void main(String[] args) throws ProductCodeNotPresent  {
		// TODO Auto-generated method stub
		
		ProductService productService=new ProductService();
		Product product=new Product();
		while(true)
		{
			System.out.println("1. Generate bill by entering Product code and quantity\n2. Exit\nEnter your choice");
			Scanner scan=new Scanner(System.in);
			int choice=scan.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("Enter the product code");
				int code=scan.nextInt();
				System.out.println("Enter the quantity");
				int quantity=scan.nextInt();
				try 
				{
					
					product=productService.getProductDetails(code, quantity);
					if(product.getProductId()!=code)
					{
						System.out.println("Sorry! The Product Code<<product_code>> is not available.");
					}
					else
					{
						System.out.println(product+"\nQuantity:              "+quantity+"\nLine Total(Rs):      "
								+ product.getLineTotal()+"\n----------------------------------------------");
					}
					
				}
			
				catch( QuantityException | ProductCodeExceeption e)
				{
					if(e instanceof QuantityException)
					{
						System.out.println(e);
					}
					if(e instanceof ProductCodeExceeption)
					{
						System.out.println(e);
					}
					if(e instanceof ProductCodeNotPresent)
					{
						System.out.println(e);
					}
				}
				break;
			case 2:
				System.exit(0);
				break;
			default: 
				System.out.println("Entered wrong option");
				break;		
			}
		}


	}

}
