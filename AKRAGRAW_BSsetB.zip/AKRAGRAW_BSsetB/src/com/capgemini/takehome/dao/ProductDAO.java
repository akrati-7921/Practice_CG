package com.capgemini.takehome.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.exception.ProductCodeExceeption;
import com.capgemini.takehome.exception.ProductCodeNotPresent;
import com.capgemini.takehome.exception.QuantityException;
import com.capgemini.takehome.util.CollectionUtil;

public class ProductDAO implements IProductDAO{

	
	//------------------------ 1. Billing Software Application --------------------------
			/*******************************************************************************************************
			 - Function Name	:	getProductDetails(int productCode,int quantity
			 - Input Parameters	:	int productCode,int quantity
			 - Return Type		:	Product
			 - Throws			:  	QuantityException, ProductCodeExceeption
			 - Author			:	CAPGEMINI
			 - Creation Date	:	12/02/2019
			 - Description		:	Claculating Total
			 ********************************************************************************************************/
		
	Map<Integer,Product> products=new HashMap<Integer,Product>();
	CollectionUtil collect=new CollectionUtil();
	Product proObj=new Product();
	
	@Override
	public Product getProductDetails(int productCode,int quantity) throws QuantityException, ProductCodeExceeption, ProductCodeNotPresent {
		// TODO Auto-generated method stub
		
		products=collect.productObject();
		
		if(quantity<=0)
		{
			throw new QuantityException("Quantity should not be lesser tahn or equal to zero");
		}
		
		String checkCode=Integer.toString(productCode);
		if(checkCode.length()!=4)
		{
			throw new ProductCodeExceeption("Product Code must be of 4 digit");
		}
		if(checkCode.length()==4 && !(products.containsKey(productCode)))
		{
			throw new ProductCodeNotPresent();
		}
		
		if(products.containsKey(productCode))
		{
			proObj=products.get(productCode);
			proObj.setLineTotal(proObj.getProductPrice()*quantity);
			return proObj;
		}
		
		return null;
	}
	
	
}
