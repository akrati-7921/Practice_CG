package com.cg.practice_work.dao;

import java.util.Map;

public interface IProductDAO {

	public int updateProducts(String Category,int hike);
	public Map<String,Integer> getProductDetails();
}
