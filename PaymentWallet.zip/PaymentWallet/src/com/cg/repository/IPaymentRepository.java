package com.cg.repository;

import com.cg.bean.Customer;

public interface IPaymentRepository {

	public Customer createAccount(String name,String phone, double amount);
	public Customer showBalance(String phone);
}
