package com.cg.pp.exception;

public class AccountException extends Exception{

	private static final long serialVersionUID = 1L;

	public AccountException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public AccountException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
