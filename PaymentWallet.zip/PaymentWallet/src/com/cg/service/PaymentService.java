package com.cg.service;

import com.cg.bean.Customer;
import com.cg.repository.PaymentRepository;

public class PaymentService implements IPaymentService{

	PaymentRepository repo=new PaymentRepository();
	Customer cust;
	@Override
	public Customer createAccount(String name, String phone, double amount) {
		// TODO Auto-generated method stub
		cust=repo.createAccount(name, phone, amount);
		return cust;
	}

	@Override
	public Customer showBalance(String phone) {
		// TODO Auto-generated method stub
		cust=repo.showBalance(phone);
		return cust;
	}

}
