package com.cg.ems.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.ems.dto.Address;
import com.cg.ems.dto.Student;
import com.cg.ems.util.JPAUtil;

public class TestOneToOneDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManager em=JPAUtil.getEntityManager();
		EntityTransaction et=em.getTransaction();
		
		/*Address vAddress=new Address();
		vAddress.setCity("Mumbai");
		vAddress.setState("Maharashtra");
		vAddress.setStreet("Borivali");
		vAddress.setZipcode("277856");
		
		Address rAddress=new Address();
		rAddress.setCity("Aligarh");
		rAddress.setState("Up");
		rAddress.setStreet("Khirni Gate");
		rAddress.setZipcode("202001");
		
		Student shivangi=new Student();
		shivangi.setStuName("Shivangi Tripathi");
		shivangi.setStuAddress(vAddress);
		
		Student yashu=new Student();
		yashu.setStuName("Yashasvi Vaishitha");
		yashu.setStuAddress(rAddress);
		
		et.begin();
		em.persist(shivangi);
		em.persist(yashu);
		et.commit();
		
		System.out.println("Data inserted in table");
		*/
		System.out.println("---------Fetch Student-----------");
		
		Student st=em.find(Student.class, 22);
		System.out.println(st);
		et.begin();
		em.remove(st);
		et.commit();
		System.out.println(st+ "removed...");
		
		
	// gives error because its have a foreign key relationship with student
		System.out.println("---------Fetch Address-----------");
		
		Address ad=em.find(Address.class, 27);
		System.out.println(ad);
		et.begin();
		em.remove(ad);
		et.commit();
		System.out.println(ad+ "removed...");
		
	}

}
