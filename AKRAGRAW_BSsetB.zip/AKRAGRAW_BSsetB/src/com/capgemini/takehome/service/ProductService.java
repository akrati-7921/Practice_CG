package com.capgemini.takehome.service;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.dao.ProductDAO;
import com.capgemini.takehome.exception.ProductCodeExceeption;
import com.capgemini.takehome.exception.ProductCodeNotPresent;
import com.capgemini.takehome.exception.QuantityException;

public class ProductService implements IProductService{

	
	//------------------------ 1. Billing Software Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	getProductDetails(int productCode,int quantity
		 - Input Parameters	:	int productCode,int quantity
		 - Return Type		:	Product
		 - Throws			:  	QuantityException, ProductCodeExceeption
		 - Author			:	CAPGEMINI
		 - Creation Date	:	12/02/2019
		 - Description		:	Claculating Total
		 ********************************************************************************************************/
	
	Product product;
	ProductDAO productDaoOb=new ProductDAO();
	
	@Override
	public Product getProductDetails(int productCode,int quantity) throws QuantityException, ProductCodeExceeption, ProductCodeNotPresent{
		// TODO Auto-generated method stub
		
		product=productDaoOb.getProductDetails(productCode, quantity);
		if(product.getProductId()==0)
		{
			return null;
		}
		else
		{
			return product;
		}
	}

}
