package com.capgemini.takehome.exception;

public class ProductCodeExceeption extends Exception{

	private static final long serialVersionUID = 1L;
	
	public String code;

	public ProductCodeExceeption(String code) {
		super();
		this.code = code;
	}

	@Override
	public String toString() {
		return "ProductCodeExceeption: "+code;
	}
	
	
}
