package com.cg.springmvc.bean;

import java.util.ArrayList;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Customer {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int customerId;
	
	@NotEmpty(message="First Name cannot be blank")
	@Pattern(regexp="[A-Z][a-z]{4,}",message="Name should contain only alphabets")
	private String firstName;
	
	@NotEmpty(message="Last Name cannot be blank")
	@Pattern(regexp="[A-Z][a-z]{4,}",message="Name should contain only alphabets")
	private String lastName;
	
	@Min(value = 20,message="Age should be >20")
	@Max(value = 50,message="Agr should be <50")
	private int age;
	
	private String email;
	
	@NotEmpty(message="Mobile Number cannot be blank")
	@Pattern(regexp="[6-9][0-9]{9}",message="Mobile Number should be of 10 digits")
	private String mobileNo;
	
	private ArrayList<String> city;
	
	public String getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public int getAge() {
		return age;
	}
	
	public void setAge(int age) {
		this.age = age;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getMobileNo() {
		return mobileNo;
	}
	
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public ArrayList<String> getCity() {
		return city;
	}

	public void setCity(ArrayList<String> city) {
		this.city = city;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	
	
}
