package com.cg.hr.core.dao;

import java.util.ArrayList;
import com.cg.hr.core.bean.Employee;
import com.cg.hr.core.exception.EmpException;

public interface EmployeeDao {
	
	public ArrayList<Employee> fetchAllEmp() throws EmpException;
	public Employee getEmpbyEid(int empId) throws EmpException;
	
}
