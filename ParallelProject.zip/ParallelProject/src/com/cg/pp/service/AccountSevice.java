package com.cg.pp.service;

import com.cg.pp.bean.Account;
import com.cg.pp.dao.AccountDao;
import com.cg.pp.dao.IAccountDao;

public class AccountSevice implements IAccountService{

	IAccountDao accountDao=null;
	public AccountSevice() {
		// TODO Auto-generated constructor stub
		accountDao = new AccountDao();
	}
	
	@Override
	public void createAccount(int accNo, String name, String mobileNo, double amount) {
		// TODO Auto-generated method stub
		accountDao.createAccount(accNo, name, mobileNo, amount);
	}

	@Override
	public void withdraw(int accNo,double amount) {
		// TODO Auto-generated method stub
		accountDao.withdraw(accNo,amount);
	}

	@Override
	public void deposit(int accNo,double amount) {
		// TODO Auto-generated method stub
		accountDao.deposit(accNo,amount);
	}

	@Override
	public double showBalance(int accNo) {
		// TODO Auto-generated method stub
		return accountDao.showBalance(accNo);
	}

	@Override
	public Account printTtansaction(int accNo) {
		// TODO Auto-generated method stub
		return accountDao.printTtansaction(accNo);
	}

	@Override
	public void fundTransfer(int senderAccNo,int receiverAccNo, double amount) {
		// TODO Auto-generated method stub
		accountDao.fundTransfer(senderAccNo,receiverAccNo, amount);
	} 

}
