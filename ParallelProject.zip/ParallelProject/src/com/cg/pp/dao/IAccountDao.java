package com.cg.pp.dao;

import com.cg.pp.bean.Account;

public interface IAccountDao {

	public void createAccount(int accNo,String name,String mobileNo,double amount);
	public void withdraw(int accNo,double amount);
	public void deposit(int accNo,double amount);
	public double showBalance(int accNo);
	public Account printTtansaction(int accNo);
	public void fundTransfer(int senderAccNo,int receiverAccNo,double amount);
	
}
