package com.cg.practice_work.service;

import java.util.Map;

public interface IProductService {

	public int updateProducts(String Category,int hike);
	public Map<String,Integer> getProductDetails();
	
}
