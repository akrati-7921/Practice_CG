package com.cg.hr.core.listener;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.cg.hr.core.exception.EmpException;
import com.cg.hr.core.srvice.EmployeeService;
import com.cg.hr.core.srvice.EmployeeServiceImpl;


@WebListener
public class CreateServiceResources implements ServletContextListener {

	private EmployeeService service;
	
    public void contextDestroyed(ServletContextEvent arg0)  { 
         // TODO Auto-generated method stub
    	service=null;
    }

	
    public void contextInitialized(ServletContextEvent arg0)  { 
         // TODO Auto-generated method stub
    	try {
			service=new EmployeeServiceImpl();
			ServletContext ctx=arg0.getServletContext();
			ctx.setAttribute("services",service);
		} catch (EmpException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    }
	
}
