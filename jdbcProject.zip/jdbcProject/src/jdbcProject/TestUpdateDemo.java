package jdbcProject;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import com.cg.ems.util.DBUtil;

public class TestUpdateDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan=new Scanner(System.in);
		System.out.println("Enter empid u want to update");
		int eid=scan.nextInt();
		System.out.println("Enter updated emp name");
		scan.nextLine();
		String enm=scan.nextLine();
		System.out.println("Enter updated emp salary");
		float esal=scan.nextFloat();
		try {
			Connection con=DBUtil.getCon();
			String updateQry="UPDATE emp1 set emp_name=?,emp_sal=? WHERE emp_id=?";
			//For dynamic query use prepared statement
			PreparedStatement pst=con.prepareStatement(updateQry);
			pst.setString(1,enm);
			pst.setFloat(2,esal);
			pst.setInt(3,eid);
			int data=pst.executeUpdate();
			System.out.println("Data is updated... "+ data);
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
